<template>
  <v-App dark :style="{backgroundColor: $vuetify.theme.dark ? '#0a0514' : 'white'}">
    <v-main>
      <Nuxt/>
    </v-main>
  </v-App>
</template>

<script>
export default {
  
}
</script>