<template>
    <div>
        <v-app-bar app color="surface" height="80" class="el" :style="{padding : $vuetify.breakpoint.mdAndUp ? '0px 100px': ''}">
            <v-toolbar-title @click="$router.push('/')" class="text-md-h5 font-weight-bold pointer">
                MarketPlace
            </v-toolbar-title>
            <v-spacer/>
            <v-btn icon nuxt to="/products">
                <v-icon size="20">mdi-store-outline</v-icon>
            </v-btn>
            <v-badge v-if="$store.state.cart.cart.length" overlap :content="$store.state.cart.cart.length">
                <v-btn nuxt to="/cart" icon>
                <v-icon size="20">mdi-cart-outline</v-icon>
            </v-btn>
            </v-badge>
            <v-btn nuxt to="/cart" v-else icon>
                <v-icon size="20">mdi-cart-outline</v-icon>
            </v-btn>
            <v-divider vertical class="mx-md-5 mx-2"></v-divider>
            <v-btn @click="toggleTheme" icon>
                <v-icon size="20">mdi-brightness-7</v-icon>
            </v-btn>
        </v-app-bar>
    </div>
</template>

<script>
    export default {
        methods:{
            toggleTheme(){
                this.$vuetify.theme.dark = !this.$vuetify.theme.dark
            }
        }
    }
</script>

<style lang="scss" scoped>

</style>